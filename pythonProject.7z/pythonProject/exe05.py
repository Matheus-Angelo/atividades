sexo = input("digite F para feminino ou M para masculino:")

if sexo in "Ff":
    print("feminino")
elif sexo in "Mm":
    print("masculino")
else:
    print("invalido")
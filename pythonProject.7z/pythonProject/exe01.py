

media = int(input("digite a idade:"))

if idade <=21:
    print("voçe e jovem")

else:
    print("voce e adulto")











#Faça um Programa que verifique se uma letra digitada é vogal ou consoante.
letra = input("digite uma letra:")
if = letra ()
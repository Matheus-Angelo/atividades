num1 = float(input("Digite um numero:"))
if num1 > 0:
    print("positivo")
elif num1 < 0:
    print("negativo")
else:
    print("zero")
score1 = float(input("input your score1:"))
score2 = float(input("input your score2:"))
mean_score = (score1 + score2)/2
if mean_score >= 5:
    if mean_score >=7:
        print("APROVADO")
    else:
        print("faça outra avaliação")
else:
    print("reprovado")



#Faça um Programa que peça dois números e imprima o maior deles.
num1 = float(input("Digite um numero:"))
num2 = float(input("digite um numero:"))

if num1 > num2:
    print(f"o numero {num1} e maior que {num2}")
elif num1 < num2:
    print(f"o numero {num2} e maior que {num1}")
else:
    print(f"os numeros sao iguais")
